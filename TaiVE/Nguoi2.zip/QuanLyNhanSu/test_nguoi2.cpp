// Test module Nguoi 2: PhongBan + HopDongLaoDong
// Day la file test rieng (co main rieng), KHONG dua vao build cua chuong trinh chinh.
//
// Bien dich (chay tu thu muc goc HeThongQuanTriNhanSu/):
//   g++ -std=c++17 -Wall NhanVien/*.cpp PhongBan/*.cpp Test/test_nguoi2.cpp -o test_nguoi2
#include <iostream>
#include <sstream>
#include "include/NhanVien/NhanVienToanThoiGian.h"
#include "include/NhanVien/NhanVienBanThoiGian.h"
#include "include/NhanVien/QuanLy.h"
#include "include/NhanVien/ChuyenGia.h"
#include "include/PhongBan/PhongBan.h"
#include "include/PhongBan/HopDongLaoDong.h"

using namespace std;

static int soLoi = 0;

#define KIEM_TRA(dieuKien)                                                        \
    do {                                                                          \
        if (dieuKien) cout << "  [PASS] " << #dieuKien << endl;                   \
        else { cout << "  [FAIL] " << #dieuKien << endl; ++soLoi; }               \
    } while (0)

int main()
{
    // ===== Du lieu mau: 4 nhan vien thuoc 4 ngach =====
    auto ttg = make_shared<NhanVienToanThoiGian>();
    ttg->setMaNV("NV01"); ttg->setHoTen("Nguyen Van A"); ttg->setNgaySinh("01/01/1998");
    ttg->setSoDienThoai("0901111111"); ttg->setEmail("a@cty.vn");
    ttg->setSoNgayCong(22); ttg->setSoGioLam(176); ttg->setCaLamViec("Hanh chinh");

    auto btg = make_shared<NhanVienBanThoiGian>();
    btg->setMaNV("NV02"); btg->setHoTen("Tran Thi B"); btg->setNgaySinh("02/02/2000");
    btg->setSoDienThoai("0902222222"); btg->setEmail("b@cty.vn");
    btg->setSoGioLam(80); btg->setLuongTheoGio(30000);

    auto ql = make_shared<QuanLy>();
    ql->setMaNV("NV03"); ql->setHoTen("Le Van C"); ql->setNgaySinh("03/03/1985");
    ql->setSoDienThoai("0903333333"); ql->setEmail("c@cty.vn");
    ql->setChucVu("Truong phong"); ql->setCapQuanLy("Cap 2"); ql->setThongTinDacThu("Phu trach du an");

    auto cg = make_shared<ChuyenGia>();
    cg->setMaNV("NV04"); cg->setHoTen("Pham Thi D"); cg->setNgaySinh("04/04/1990");
    cg->setSoDienThoai("0904444444"); cg->setEmail("d@cty.vn");
    cg->setChuyenMon("AI"); cg->setSoNamKinhNghiem(8);

    // ===== PhongBan =====
    cout << "\n--- 1. Them nhan vien (da hinh, 4 ngach) ---" << endl;
    PhongBan pb("PB01", "Phong Ky Thuat");
    KIEM_TRA(pb.themNhanVien(ttg));
    KIEM_TRA(pb.themNhanVien(btg));
    KIEM_TRA(pb.themNhanVien(ql));
    KIEM_TRA(pb.themNhanVien(cg));
    KIEM_TRA(pb.getSoLuongNhanVien() == 4);

    cout << "\n--- 2. Truong hop loi khi them ---" << endl;
    KIEM_TRA(!pb.themNhanVien(nullptr));      // con tro rong
    KIEM_TRA(!pb.themNhanVien(ttg));          // trung ma
    KIEM_TRA(!pb.themNhanVien(make_shared<ChuyenGia>())); // chua co ma
    KIEM_TRA(pb.getSoLuongNhanVien() == 4);

    cout << "\n--- 3. Tim kiem ---" << endl;
    KIEM_TRA(pb.coNhanVien("NV03"));
    KIEM_TRA(!pb.coNhanVien("NV99"));
    KIEM_TRA(pb.timNhanVien("NV02") == btg);
    KIEM_TRA(pb.timNhanVien("NV99") == nullptr);

    cout << "\n--- 4. Downcast an toan cho Nguoi 3/4 ---" << endl;
    auto dsBTG = pb.layTheoKieu<NhanVienBanThoiGian>();
    KIEM_TRA(dsBTG.size() == 1);
    KIEM_TRA(dsBTG[0]->getLuongTheoGio() == 30000);
    KIEM_TRA(pb.layTheoKieu<QuanLy>().size() == 1);
    KIEM_TRA(pb.layTheoKieu<ChuyenGia>()[0]->getSoNamKinhNghiem() == 8);

    cout << "\n--- 5. Xuat phong ban (kiem tra bang mat) ---" << endl;
    pb.xuat();

    cout << "\n--- 6. Xoa nhan vien ---" << endl;
    KIEM_TRA(pb.xoaNhanVien("NV04"));
    KIEM_TRA(!pb.xoaNhanVien("NV04"));
    KIEM_TRA(pb.getSoLuongNhanVien() == 3);
    KIEM_TRA(cg->getHoTen() == "Pham Thi D");   // nhan vien van song vi con shared_ptr o ngoai

    cout << "\n--- 7. Mot nhan vien o 2 phong ban (shared ownership) ---" << endl;
    PhongBan pb2("PB02", "Phong Du An");
    KIEM_TRA(pb2.themNhanVien(ql));
    KIEM_TRA(ql.use_count() >= 3);              // ql + pb + pb2

    cout << "\n--- 8. Setter phong ban ---" << endl;
    pb.setTenPhongBan("");                      // phai bao loi, khong doi ten
    KIEM_TRA(pb.getTenPhongBan() == "Phong Ky Thuat");
    KIEM_TRA(pb.kiemTraHopLe());
    KIEM_TRA(!PhongBan().kiemTraHopLe());

    cout << "\n--- 9. PhongBan::nhap() tu stdin ---" << endl;
    {
        istringstream in("PB09\nPhong Nhan Su\n");
        streambuf* cu = cin.rdbuf(in.rdbuf());
        PhongBan pb3;
        pb3.nhap();
        cin.rdbuf(cu);
        KIEM_TRA(pb3.getMaPhongBan() == "PB09" && pb3.getTenPhongBan() == "Phong Nhan Su");
    }

    // ===== HopDongLaoDong =====
    cout << "\n--- 10. Hop dong ---" << endl;
    HopDongLaoDong hd("HD01", "Chinh thuc", "01/06/2025", 15000000, ttg);
    KIEM_TRA(hd.kiemTraHopLe());
    KIEM_TRA(hd.getLuongThoaThuan() == 15000000);
    KIEM_TRA(hd.getNguoiLaoDong() == ttg);
    hd.xuat();

    cout << "\n--- 11. Doi thong tin NV -> hop dong thay ngay (khong copy du lieu) ---" << endl;
    ttg->setHoTen("Nguyen Van A (da doi ten)");
    KIEM_TRA(hd.getNguoiLaoDong()->getHoTen() == "Nguyen Van A (da doi ten)");

    cout << "\n--- 12. Hop dong loi ---" << endl;
    HopDongLaoDong rong;
    KIEM_TRA(!rong.kiemTraHopLe());
    rong.setNguoiLaoDong(nullptr);              // bao loi, van nullptr
    KIEM_TRA(rong.getNguoiLaoDong() == nullptr);
    rong.setLuongThoaThuan(-5);                 // bao loi, giu nguyen
    KIEM_TRA(rong.getLuongThoaThuan() == 0);
    rong.xuat();                                // phai in "chua duoc gan", khong crash

    cout << "\n--- 13. HopDongLaoDong::nhap() tu stdin (co nhap sai luong) ---" << endl;
    {
        istringstream in("HD02\nThoi vu\n15/09/2025\nabc\n-10\n7500000\n");
        streambuf* cu = cin.rdbuf(in.rdbuf());
        HopDongLaoDong hd2;
        hd2.nhap();
        cin.rdbuf(cu);
        hd2.setNguoiLaoDong(btg);
        KIEM_TRA(hd2.getMaHopDong() == "HD02");
        KIEM_TRA(hd2.getLuongThoaThuan() == 7500000);
        KIEM_TRA(hd2.kiemTraHopLe());
    }

    cout << "\n=========================================" << endl;
    if (soLoi == 0) cout << "TAT CA TEST DEU PASS" << endl;
    else cout << "CO " << soLoi << " TEST FAIL" << endl;
    return soLoi == 0 ? 0 : 1;
}
