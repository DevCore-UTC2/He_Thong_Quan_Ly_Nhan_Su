# Bàn giao Người 2 → Người 3: PhongBan + HopDongLaoDong

Branch: `feature/phongban`
Commit gợi ý: `feat: complete PhongBan and HopDongLaoDong module`

## Cấu trúc
```
HeThongQuanTriNhanSu/
├── NhanVien/        (Người 1, KHÔNG sửa)
├── PhongBan/
│   ├── PhongBan.h / PhongBan.cpp
│   └── HopDongLaoDong.h / HopDongLaoDong.cpp
└── Test/test_nguoi2.cpp   (có main riêng, KHÔNG đưa vào build chính)
```
Include: `#include "../PhongBan/PhongBan.h"` và `#include "../PhongBan/HopDongLaoDong.h"`.

Build + test (từ thư mục gốc):
`g++ -std=c++17 -Wall NhanVien/*.cpp PhongBan/*.cpp Test/test_nguoi2.cpp -o test_nguoi2 && ./test_nguoi2`

## Quy tắc quan trọng
- Nhân viên luôn được dùng qua `shared_ptr<NhanVien>` (tạo bằng `make_shared<NhanVienToanThoiGian>()`...).
  **Không** dùng `vector<NhanVien>` (mất dữ liệu lớp con do object slicing).
- Phòng ban và hợp đồng cùng trỏ tới một đối tượng nhân viên, không sao chép dữ liệu.
  Xóa khỏi phòng ban chỉ gỡ con trỏ, nhân viên vẫn sống nếu nơi khác còn giữ.

## Hàm public Người 3 / 4 cần dùng

### PhongBan
| Hàm | Ghi chú |
|---|---|
| `getMaPhongBan()`, `getTenPhongBan()`, `getSoLuongNhanVien()` | |
| `getDanhSachNhanVien()` | `const vector<shared_ptr<NhanVien>>&`, duyệt bằng `for (const auto& nv : ds)` |
| `layTheoKieu<T>()` | Trả `vector<shared_ptr<T>>` đã downcast, VD `pb.layTheoKieu<NhanVienBanThoiGian>()` (nhớ include header của T) |
| `timNhanVien(maNV)` / `coNhanVien(maNV)` | `nullptr` / `false` nếu không có |
| `themNhanVien(nv)` / `xoaNhanVien(maNV)` | Trả `bool`; từ chối nullptr, nhân viên chưa có mã, trùng mã |
| `nhap()`, `xuat()`, `capNhatThongTin()`, `kiemTraHopLe()` | Cùng phong cách với module Người 1 |

### HopDongLaoDong
| Hàm | Ghi chú |
|---|---|
| `getMaHopDong()`, `getLoaiHopDong()`, `getNgayKyKet()` | |
| `getLuongThoaThuan()` | `double`, VND, **lương cơ bản đầu vào cho Người 4** |
| `getNguoiLaoDong()` | `shared_ptr<NhanVien>`, có thể `nullptr` nếu chưa gán, nhớ kiểm tra |
| `setNguoiLaoDong(nv)` | `nhap()` không gán nhân viên, phải gọi hàm này sau |
| `nhap()`, `xuat()`, `capNhatThongTin()`, `kiemTraHopLe()` | `kiemTraHopLe()` yêu cầu đã gán nhân viên |

## Ví dụ lấy dữ liệu để tính lương
```cpp
for (const auto& nv : pb.getDanhSachNhanVien()) {
    if (auto bt = dynamic_pointer_cast<NhanVienBanThoiGian>(nv)) {
        double tien = bt->getSoGioLam() * bt->getLuongTheoGio();
    }
}
```

## Lưu ý
1. Chưa có chỗ chứa "danh sách nhiều PhongBan / nhiều HopDong" và hàm "tìm hợp đồng theo nhân viên".
   Theo phân công, phần quản lý tập hợp này thuộc `main`/UI (Người 5), có thể dùng `vector<PhongBan>`,
   `vector<HopDongLaoDong>`. Nếu Người 3/4 cần, hãy báo Người 2 bổ sung.
2. `NhanVien` chưa có `getLuongCoBan()` như ví dụ trong quy ước; lương cơ bản hiện nằm ở `HopDongLaoDong`.
3. Module Người 1: `kiemTraThongTinRieng()` của các lớp con **không** phải hàm ảo, nên không gọi được qua
   `shared_ptr<NhanVien>` (phải downcast trước). Chưa sửa vì quy ước cấm sửa module đã bàn giao khi chưa báo;
   đề nghị Người 1 xem xét.
4. Phần xử lý lỗi hiện in thông báo ra màn hình (giống Người 1) và trả về `false`/giữ giá trị cũ.
   Người 5 có thể chuyển sang ném exception khi làm module Exception.
